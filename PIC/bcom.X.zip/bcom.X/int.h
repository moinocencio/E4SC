#ifndef __INT_H__
#define __INT_H__

void enableInterrupts();
void disableInterrupts();
void config_adcInt();
void config_extInt1();
void config_extInt2();
void config_extInt3();
void config_extInt4();
void config_Inttimer2();
void config_Inttimer5();

#endif